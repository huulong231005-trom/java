package vn.edu.eaut.lab10.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab10.repository.UserRepository;
import java.io.IOException;

@WebServlet("/admin/users")
public class UserController extends HttpServlet {
    private final UserRepository userRepo = new UserRepository();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("users", userRepo.findAll());
        req.getRequestDispatcher("/admin/user-list.jsp").forward(req, resp);
    }
}