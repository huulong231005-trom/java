<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html><head><title>Quản lý Người dùng</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5">
    <h2>Danh sách Người dùng (Bảo vệ bởi Admin Filter)</h2>
    <a href="${pageContext.request.contextPath}/dashboard.jsp" class="btn btn-secondary mb-3">Về Dashboard</a>
    <table class="table table-bordered table-hover">
        <thead class="table-dark"><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Vai trò</th><th>Trạng thái</th></tr></thead>
        <tbody>
            <c:forEach var="u" items="${users}">
                <tr><td>${u.id}</td><td>${u.fullName}</td><td>${u.email}</td>
                <td><span class="badge bg-primary">${u.role}</span></td>
                <td>${u.active ? '<span class="text-success">Hoạt động</span>' : '<span class="text-danger">Đã khóa</span>'}</td></tr>
            </c:forEach>
        </tbody>
    </table>
</body></html>