<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html><head><title>Dashboard</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark px-4">
        <a class="navbar-brand" href="#">Lab 10 Dashboard</a>
        <span class="text-white">Xin chào, ${currentUser.fullName} (${currentUser.role}) | <a href="${pageContext.request.contextPath}/auth?action=logout" class="text-danger">Đăng xuất</a></span>
    </nav>
    <div class="container mt-5">
        <h2 class="mb-4">Menu Chức Năng</h2>
        <div class="list-group w-50">
            <c:if test="${currentUser.role == 'ADMIN'}">
                <a href="${pageContext.request.contextPath}/admin/users" class="list-group-item list-group-item-action list-group-item-danger">Quản lý Người dùng (Chỉ Admin)</a>
            </c:if>
            <c:if test="${currentUser.role == 'ADMIN' || currentUser.role == 'STAFF'}">
                <a href="#" class="list-group-item list-group-item-action list-group-item-warning">Quản lý Nghiệp vụ (Staff + Admin)</a>
            </c:if>
            <a href="#" class="list-group-item list-group-item-action list-group-item-info">Hồ sơ cá nhân (Tất cả User)</a>
        </div>
    </div>
</body></html>