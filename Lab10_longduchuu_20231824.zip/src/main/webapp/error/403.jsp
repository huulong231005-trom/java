<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><body style="text-align:center; padding-top: 100px; font-family: Arial;">
    <h1 style="color:red; font-size: 50px;">403</h1>
    <h2>BẠN KHÔNG CÓ QUYỀN TRUY CẬP TRANG NÀY!</h2>
    <p>URL này được bảo vệ bởi AuthorizationFilter. Chỉ Role cấp cao mới được phép.</p>
    <a href="${pageContext.request.contextPath}/dashboard.jsp">Quay về Dashboard</a>
</body></html>