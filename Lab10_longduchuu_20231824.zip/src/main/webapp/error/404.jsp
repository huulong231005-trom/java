<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><body style="text-align:center; padding-top: 100px; font-family: Arial;">
    <h1 style="color:orange; font-size: 50px;">404</h1>
    <h2>Không tìm thấy trang yêu cầu!</h2>
    <a href="${pageContext.request.contextPath}/dashboard.jsp">Quay về Dashboard</a>
</body></html>