<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html><head><title>Đăng nhập hệ thống</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">
    <div class="card shadow p-4" style="width: 400px;">
        <h3 class="text-center text-primary mb-4">Đăng nhập Lab 10</h3>
        <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
        <form method="post" action="${pageContext.request.contextPath}/auth">
            <div class="mb-3"><label>Email:</label><input type="email" name="email" class="form-control" value="admin@eaut.edu.vn" required></div>
            <div class="mb-3"><label>Mật khẩu:</label><input type="password" name="password" class="form-control" value="admin123" required></div>
            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
        </form>
        <p class="mt-3 text-muted text-center" style="font-size: 12px;">Admin: admin@eaut.edu.vn / admin123<br>User: user@eaut.edu.vn / user123</p>
    </div>
</body></html>