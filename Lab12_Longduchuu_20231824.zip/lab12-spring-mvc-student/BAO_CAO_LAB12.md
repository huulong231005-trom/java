# BÁO CÁO NGẮN LAB 12 - SPRING MVC

## 1. Mục tiêu
Xây dựng ứng dụng CRUD sinh viên bằng Spring MVC, Thymeleaf, ModelAttribute và Validation.

## 2. Luồng GET
Trình duyệt gửi GET `/students` -> `StudentController` nhận request -> gọi `StudentService` lấy danh sách -> đưa danh sách vào `Model` -> trả về view `students/list` -> Thymeleaf render HTML.

## 3. Luồng GET form
GET `/students/create` -> Controller tạo `new Student()` -> đưa vào Model với tên `student` -> `students/form.html` dùng `th:object` và `th:field` để binding.

## 4. Luồng POST
Form gửi POST `/students/save` -> `@ModelAttribute` binding dữ liệu vào Student -> `@Valid` kiểm tra validation -> `BindingResult` chứa lỗi -> nếu có lỗi thì trả lại form -> nếu hợp lệ thì Service lưu dữ liệu -> redirect `/students`.

## 5. CRUD
- Create: `/students/create`, POST `/students/save`
- Read: `/students`, `/students/detail/{id}`
- Update: `/students/edit/{id}`, POST `/students/save`
- Delete: `/students/delete/{id}`
- Search: `/students?keyword=...`

## 6. Validation
Student sử dụng:
- `@NotBlank`
- `@Size`
- `@Email`

Ngoài ra Controller kiểm tra mã sinh viên bị trùng trong danh sách.

## 7. Kết luận
Ứng dụng tổ chức theo mô hình MVC và tách Service để thuận lợi chuyển từ dữ liệu trong bộ nhớ sang CSDL ở các bài sau.
