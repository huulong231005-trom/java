# Lab 12 - Spring MVC Student

Package: `vn.edu.eaut.lab12`

## Chức năng
- Danh sách sinh viên
- Thêm sinh viên
- Validation form
- Mã sinh viên không trùng
- Xem chi tiết
- Chỉnh sửa
- Xóa
- Tìm kiếm theo họ tên

## Chạy project

Yêu cầu JDK 17 hoặc JDK 21 và Maven.

```bash
mvn clean package
mvn spring-boot:run
```

Mở:
`http://localhost:8080`

Danh sách:
`http://localhost:8080/students`

## Cấu trúc MVC
- Model: `Student.java`
- Service: `StudentService.java`
- Controller: `StudentController.java`
- View: `src/main/resources/templates/students/`

Dữ liệu hiện được lưu trong `List` ở bộ nhớ, chưa dùng MySQL/JPA.
