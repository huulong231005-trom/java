package vn.edu.eaut.lab12.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import vn.edu.eaut.lab12.model.Student;
import vn.edu.eaut.lab12.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // Bài 3 + Bài 9: danh sách và tìm kiếm
    @GetMapping
    public String list(@RequestParam(required = false) String keyword, Model model) {
        model.addAttribute("students", studentService.search(keyword));
        model.addAttribute("keyword", keyword == null ? "" : keyword);
        return "students/list";
    }

    // Bài 4: form thêm
    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("pageTitle", "Thêm sinh viên");
        return "students/form";
    }

    // Bài 7: form sửa
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Student student = studentService.findById(id);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy sinh viên!");
            return "redirect:/students";
        }
        model.addAttribute("student", student);
        model.addAttribute("pageTitle", "Chỉnh sửa sinh viên");
        return "students/form";
    }

    // Bài 5 + Bài 10: validation và mã SV không trùng
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student student,
                       BindingResult result,
                       Model model) {
        if (studentService.existsStudentCode(student.getStudentCode(), student.getId())) {
            result.rejectValue("studentCode", "duplicate",
                    "Mã sinh viên đã tồn tại");
        }

        if (result.hasErrors()) {
            model.addAttribute("pageTitle",
                    student.getId() == null ? "Thêm sinh viên" : "Chỉnh sửa sinh viên");
            return "students/form";
        }

        studentService.save(student);
        return "redirect:/students";
    }

    // Bài 6: xem chi tiết
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable Long id, Model model,
                         RedirectAttributes redirectAttributes) {
        Student student = studentService.findById(id);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy sinh viên!");
            return "redirect:/students";
        }
        model.addAttribute("student", student);
        return "students/detail";
    }

    // Bài 8: xóa
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        studentService.delete(id);
        return "redirect:/students";
    }
}
