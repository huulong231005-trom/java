package vn.edu.eaut.lab12.service;

import org.springframework.stereotype.Service;
import vn.edu.eaut.lab12.model.Student;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {
    private final List<Student> students = new ArrayList<>();
    private long nextId = 1;

    public StudentService() {
        students.add(new Student(nextId++, "SV001", "Nguyễn Văn An",
                "an@gmail.com", "CNTT01"));
        students.add(new Student(nextId++, "SV002", "Trần Thị Bình",
                "binh@gmail.com", "CNTT02"));
        students.add(new Student(nextId++, "SV003", "Lê Minh Đức",
                "duc@gmail.com", "CNTT01"));
    }

    public List<Student> findAll() {
        return students;
    }

    public List<Student> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return students;
        }
        String k = keyword.trim().toLowerCase();
        return students.stream()
                .filter(s -> s.getFullName().toLowerCase().contains(k))
                .toList();
    }

    public Student findById(Long id) {
        return students.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public boolean existsStudentCode(String studentCode, Long id) {
        return students.stream()
                .anyMatch(s -> s.getStudentCode().equalsIgnoreCase(studentCode)
                        && (id == null || !s.getId().equals(id)));
    }

    public void save(Student student) {
        if (student.getId() == null) {
            student.setId(nextId++);
            students.add(student);
        } else {
            Student existing = findById(student.getId());
            if (existing != null) {
                existing.setStudentCode(student.getStudentCode());
                existing.setFullName(student.getFullName());
                existing.setEmail(student.getEmail());
                existing.setClassName(student.getClassName());
            }
        }
    }

    public void delete(Long id) {
        students.removeIf(s -> s.getId().equals(id));
    }
}
