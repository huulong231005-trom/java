package vn.edu.eaut.lab14.config;

import vn.edu.eaut.lab14.model.User;
import vn.edu.eaut.lab14.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initUsers(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {

        return args -> {

            if (userRepository.findByUsername("admin").isEmpty()) {

                User admin = new User();

                admin.setUsername("admin");

                admin.setPassword(
                        passwordEncoder.encode("123456")
                );

                admin.setRole("ADMIN");

                userRepository.save(admin);
            }

            if (userRepository.findByUsername("user").isEmpty()) {

                User user = new User();

                user.setUsername("user");

                user.setPassword(
                        passwordEncoder.encode("123456")
                );

                user.setRole("USER");

                userRepository.save(user);
            }
        };
    }
}