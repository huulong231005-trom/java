package vn.edu.eaut.lab14.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CourseController {

    @GetMapping("/courses")
    public String courses(Model model) {

        model.addAttribute(
                "message",
                "Trang quản lý khóa học dành cho ADMIN."
        );

        return "courses/list";
    }
}