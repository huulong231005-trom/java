package vn.edu.eaut.lab14.controller;

import vn.edu.eaut.lab14.model.Student;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final List<Student> students = new ArrayList<>();

    public StudentController() {

        students.add(
                new Student(
                        1,
                        "Nguyễn Văn An",
                        "an@gmail.com",
                        "Công nghệ thông tin"
                )
        );

        students.add(
                new Student(
                        2,
                        "Trần Thị Bình",
                        "binh@gmail.com",
                        "Kinh tế"
                )
        );

        students.add(
                new Student(
                        3,
                        "Lê Văn Cường",
                        "cuong@gmail.com",
                        "Công nghệ thông tin"
                )
        );
    }

    @GetMapping
    public String list(Model model) {

        model.addAttribute(
                "students",
                students
        );

        return "students/list";
    }

    @GetMapping("/create")
    public String createForm(Model model) {

        model.addAttribute(
                "student",
                new Student()
        );

        return "students/create";
    }

    @PostMapping("/create")
    public String create(
            @ModelAttribute Student student) {

        int newId = students.stream()
                .mapToInt(Student::getId)
                .max()
                .orElse(0) + 1;

        student.setId(newId);

        students.add(student);

        return "redirect:/students";
    }

    @GetMapping("/delete/{id}")
    public String delete(
            @PathVariable int id) {

        students.removeIf(
                student -> student.getId() == id
        );

        return "redirect:/students";
    }
}